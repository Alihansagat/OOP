package university.enums;

public enum ManagerType {
    OR, DEPARTMENT, DEAN_OFFICE, REGISTRAR
}
